using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apple.Models
{
    public class Medication
    {
      public string Name { get; set; }
    }
}
