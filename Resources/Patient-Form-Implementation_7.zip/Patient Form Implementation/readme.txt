

In this ZIP file, you find two folders: 

* apple-complete: the complete project 
* apple-partial: includes only the changes for implementing the patient form 

If you created the "Apple" project earlier, you can simply copy/paste the content 
of apple-partial and overwrite the existing files. I've deliberately separated 
this folder so you can see all the code I've written to implement the patient form. 

If for any reason, you can't run the application and get errors, use "apple-complete"
folder. Simply run:

npm install 
dotnet run 

